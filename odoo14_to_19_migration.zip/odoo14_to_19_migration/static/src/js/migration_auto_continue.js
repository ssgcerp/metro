/** @odoo-module **/

import { FormController } from "@web/views/form/form_controller";
import { patch } from "@web/core/utils/patch";

patch(FormController.prototype, {
    setup() {
        super.setup();
        this.countdownInterval = null;
        this.countdownRetryTimeout = null;
        this.countdownCheckInterval = null;
        this.countdownActive = false;
        this.lastCountdownSeconds = 0;
    },

    async onWillStart() {
        await super.onWillStart();
        
        try {
            // Use MutationObserver to detect when countdown element appears
            this.observer = new MutationObserver((mutations) => {
                try {
                    const countdownEl = document.querySelector(".o_migration_countdown");
                    if (countdownEl && !this.countdownInterval) {
                        console.log("🔍 Countdown element appeared, starting countdown...");
                        this._startAutoContinueCountdown();
                    }
                } catch (error) {
                    console.error("❌ Error in MutationObserver callback:", error);
                }
            });
            
            // Observe the document body for changes
            if (document.body) {
                this.observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            }
            
            // Wait a bit for DOM to be ready, then start
            setTimeout(() => {
                try {
                    // Only start if model is available
                    if (this.model && this.model.root) {
                        this._startAutoContinueCountdown();
                    }
                } catch (error) {
                    console.error("❌ Error starting countdown:", error);
                }
            }, 500);
            
            // Listen for countdown restart events from refresh interval
            this.countdownRestartHandler = (event) => {
                try {
                    console.log("📢 Received countdown restart event:", event.detail);
                    // Clear existing countdown before restarting
                    if (this.countdownInterval) {
                        clearInterval(this.countdownInterval);
                        this.countdownInterval = null;
                    }
                    // Reset flags to allow restart
                    this.countdownActive = false;
                    this.lastCountdownSeconds = 0;
                    setTimeout(() => {
                        try {
                            this._startAutoContinueCountdown();
                        } catch (error) {
                            console.error("❌ Error restarting countdown:", error);
                        }
                    }, 200);
                } catch (error) {
                    console.error("❌ Error in countdown restart handler:", error);
                }
            };
            document.addEventListener('migration_countdown_restart', this.countdownRestartHandler);
            
            // Also check periodically if countdown should be active (fallback)
            this.countdownCheckInterval = setInterval(() => {
                try {
                    if (this.model && this.model.root && this.model.root.data) {
                        const autoContinue = this.model.root.data.auto_continue;
                        const countdownSeconds = this.model.root.data.countdown_seconds || 0;
                        // If countdown should be active but isn't, start it
                        if (autoContinue && countdownSeconds > 0 && !this.countdownActive) {
                            console.log("🔄 Periodic check: Countdown should be active, restarting...");
                            this._startAutoContinueCountdown();
                        }
                    }
                } catch (error) {
                    console.error("❌ Error in countdown check interval:", error);
                }
            }, 2000); // Check every 2 seconds
        } catch (error) {
            console.error("❌ Error in onWillStart:", error);
        }
    },

    _startAutoContinueCountdown() {
        // Safety check: ensure model exists
        if (!this.model || !this.model.root) {
            console.log("Auto-continue: Model not available yet");
            return;
        }
        
        const record = this.model.root;
        if (!record || !record.data) {
            console.log("Auto-continue: No record data available");
            return;
        }

        // Check if auto-continue is enabled
        const autoContinue = record.data.auto_continue;
        const countdownSeconds = record.data.countdown_seconds || 0;

        console.log(`🔍 Auto-continue check: auto_continue=${autoContinue}, countdown_seconds=${countdownSeconds}, countdownActive=${this.countdownActive}, lastCountdown=${this.lastCountdownSeconds}`);

        // Always clear existing countdown before starting new one
        if (this.countdownInterval) {
            clearInterval(this.countdownInterval);
            this.countdownInterval = null;
            this.countdownActive = false;
        }
        if (this.countdownRetryTimeout) {
            clearTimeout(this.countdownRetryTimeout);
            this.countdownRetryTimeout = null;
        }

        // Start countdown if enabled and seconds > 0
        if (autoContinue && countdownSeconds > 0) {
            // Always restart countdown when conditions are met
            this.lastCountdownSeconds = countdownSeconds;
            this.countdownActive = true;
            let seconds = parseInt(countdownSeconds) || 5; // Ensure it's a number
            
            // Function to find elements with retry
            const findElements = () => {
                // Try to find elements - search in the entire document
                let countdownEl = document.querySelector(".o_migration_countdown");
                let continueBtn = document.querySelector(".o_continue_migration_btn");
                
                // If not found, try searching in modal/dialog
                if (!countdownEl) {
                    const modal = document.querySelector('.modal, .o_dialog');
                    if (modal) {
                        countdownEl = modal.querySelector(".o_migration_countdown");
                        continueBtn = modal.querySelector(".o_continue_migration_btn");
                    }
                }
                
                // Try alternative selectors
                if (!countdownEl) {
                    countdownEl = document.querySelector('[class*="migration_countdown"]');
                }
                if (!continueBtn) {
                    continueBtn = document.querySelector('[class*="continue_migration"]');
                    // Also try by button text
                    if (!continueBtn) {
                        const buttons = document.querySelectorAll('button');
                        for (const btn of buttons) {
                            if (btn.textContent && btn.textContent.includes('Continue Migration')) {
                                continueBtn = btn;
                                break;
                            }
                        }
                    }
                }
                
                return { countdownEl, continueBtn };
            };

            let { countdownEl, continueBtn } = findElements();

            if (!countdownEl || !continueBtn) {
                console.warn("⚠️ Auto-continue: Elements not found. Retrying in 500ms...", {
                    countdownEl: !!countdownEl,
                    continueBtn: !!continueBtn,
                    allCountdowns: document.querySelectorAll('.o_migration_countdown').length,
                    allButtons: document.querySelectorAll('.o_continue_migration_btn').length
                });
                // Retry after DOM is ready
                this.countdownRetryTimeout = setTimeout(() => {
                    this._startAutoContinueCountdown();
                }, 500);
                return;
            }

            console.log(`✅ Starting auto-continue countdown from ${seconds} seconds`);

            // Find or create the countdown timer span
            let span = countdownEl.querySelector("#countdown_timer");
            if (!span) {
                // Try to find any span in the countdown element
                const spans = countdownEl.querySelectorAll("span");
                for (const s of spans) {
                    if (s.textContent && s.textContent.match(/^\d+$/)) {
                        span = s;
                        span.id = "countdown_timer";
                        break;
                    }
                }
            }
            
            if (!span) {
                // Create span if it doesn't exist - find the strong tag
                const strong = countdownEl.querySelector("strong");
                if (strong) {
                    // Look for text node containing "seconds"
                    const walker = document.createTreeWalker(
                        strong,
                        NodeFilter.SHOW_TEXT,
                        null,
                        false
                    );
                    
                    let textNode = walker.nextNode();
                    while (textNode) {
                        if (textNode.textContent.includes("seconds")) {
                            // Create span and replace the number in text
                            span = document.createElement("span");
                            span.id = "countdown_timer";
                            span.style.fontWeight = "bold";
                            span.style.color = "#856404";
                            
                            // Insert before the text node
                            textNode.parentNode.insertBefore(span, textNode);
                            break;
                        }
                        textNode = walker.nextNode();
                    }
                    
                    // If still not found, just append to strong
                    if (!span) {
                        span = document.createElement("span");
                        span.id = "countdown_timer";
                        span.style.fontWeight = "bold";
                        span.style.color = "#856404";
                        strong.insertBefore(span, strong.firstChild);
                    }
                } else {
                    // No strong tag, append to countdown element
                    span = document.createElement("span");
                    span.id = "countdown_timer";
                    span.style.fontWeight = "bold";
                    span.style.color = "#856404";
                    countdownEl.appendChild(span);
                }
            }

            // Update countdown display immediately
            if (span) {
                span.textContent = seconds;
                span.style.display = "inline";
                console.log(`🎬 Countdown initialized: ${seconds} seconds`);
            } else {
                console.error("❌ Could not find or create countdown timer span");
                return;
            }

            // Store reference to elements for the interval
            const countdownElement = countdownEl;
            const continueButton = continueBtn;

            // Start countdown interval - update every second
            this.countdownInterval = setInterval(() => {
                seconds--;
                
                // Ensure seconds doesn't go below 0
                if (seconds < 0) {
                    seconds = 0;
                }

                // Always re-find span to handle DOM updates (view might reload)
                let currentSpan = document.querySelector("#countdown_timer");
                if (!currentSpan) {
                    // Try to find in countdown element
                    currentSpan = countdownElement.querySelector("#countdown_timer");
                }
                if (!currentSpan) {
                    // Try to find any span with a number in the countdown area
                    const spans = countdownElement.querySelectorAll("span");
                    for (const s of spans) {
                        if (s.id === "countdown_timer") {
                            currentSpan = s;
                            break;
                        }
                        // Check if span contains just a number (likely the countdown)
                        const text = s.textContent.trim();
                        if (text && /^\d+$/.test(text) && parseInt(text) <= 5) {
                            currentSpan = s;
                            currentSpan.id = "countdown_timer";
                            break;
                        }
                    }
                }

                // Update display
                if (currentSpan) {
                    currentSpan.textContent = seconds;
                    currentSpan.style.display = "inline";
                    console.log(`⏱️ Countdown: ${seconds} seconds remaining`);
                } else {
                    console.warn("⚠️ Countdown span not found, trying to recreate...");
                    // Try to recreate - find the countdown div first
                    const countdownDiv = document.querySelector(".o_migration_countdown");
                    if (countdownDiv) {
                        const strong = countdownDiv.querySelector("strong");
                        if (strong) {
                            // Remove any existing countdown span
                            const existing = strong.querySelector("#countdown_timer");
                            if (existing) {
                                existing.remove();
                            }
                            // Create new span
                            currentSpan = document.createElement("span");
                            currentSpan.id = "countdown_timer";
                            currentSpan.textContent = seconds;
                            currentSpan.style.fontWeight = "bold";
                            currentSpan.style.color = "#856404";
                            // Insert before the text "seconds..."
                            const textNodes = Array.from(strong.childNodes);
                            for (let i = 0; i < textNodes.length; i++) {
                                if (textNodes[i].nodeType === Node.TEXT_NODE && textNodes[i].textContent.includes("seconds")) {
                                    strong.insertBefore(currentSpan, textNodes[i]);
                                    break;
                                }
                            }
                            // If not found, just append
                            if (!currentSpan.parentNode) {
                                strong.insertBefore(currentSpan, strong.firstChild);
                            }
                            console.log(`✅ Recreated countdown span: ${seconds}`);
                        }
                    }
                }

                // When countdown reaches 0, trigger next batch
                if (seconds <= 0) {
                    clearInterval(this.countdownInterval);
                    this.countdownInterval = null;
                    this.countdownActive = false;
                    this.lastCountdownSeconds = 0;

                    console.log("🎯 Countdown reached 0. Triggering next batch...");

                    // Get fresh record reference
                    const currentRecord = this.model.root;
                    if (!currentRecord || !currentRecord.resModel) {
                        console.error("❌ No record found. Trying button click...");
                        const result = findElements();
                        if (result.continueBtn) {
                            setTimeout(() => {
                                result.continueBtn.click();
                                console.log("✅ Button clicked as fallback");
                            }, 300);
                        }
                        return;
                    }

                    // Determine which migration method to call
                    let actionMethod = 'action_migrate_quotations';
                    if (currentRecord.data && currentRecord.data.employees_migrated !== undefined) {
                        actionMethod = 'action_migrate_employees';
                    }
                    
                    // Trigger next batch - use button click (most reliable)
                    setTimeout(() => {
                        try {
                            const result = findElements();
                            if (result.continueBtn) {
                                console.log("🔄 Clicking Continue Migration button...");
                                result.continueBtn.click();
                                console.log("✅ Button clicked successfully");
                            } else {
                                console.warn("⚠️ Continue button not found, trying ORM...");
                                // Fallback: Try ORM call
                                try {
                                    const orm = this.env && this.env.services && this.env.services.orm;
                                    if (orm && currentRecord && currentRecord.resModel && currentRecord.resId) {
                                        orm.call(
                                            currentRecord.resModel,
                                            actionMethod,
                                            [[currentRecord.resId]],
                                        ).catch((error) => {
                                            console.error("❌ ORM call failed:", error);
                                        });
                                    }
                                } catch (ormError) {
                                    console.error("❌ Cannot access ORM service:", ormError);
                                }
                            }
                        } catch (error) {
                            console.error("❌ Error triggering next batch:", error);
                        }
                    }, 200);
                }
            }, 1000); // Update every 1 second
        } else {
            if (!autoContinue || countdownSeconds <= 0) {
                this.countdownActive = false;
                this.lastCountdownSeconds = 0;
            }
            console.log("Auto-continue not starting:", { autoContinue, countdownSeconds, countdownActive: this.countdownActive });
        }
    },

    onWillUnmount() {
        super.onWillUnmount();
        if (this.countdownInterval) {
            clearInterval(this.countdownInterval);
            this.countdownInterval = null;
        }
        if (this.countdownRetryTimeout) {
            clearTimeout(this.countdownRetryTimeout);
            this.countdownRetryTimeout = null;
        }
        if (this.countdownCheckInterval) {
            clearInterval(this.countdownCheckInterval);
            this.countdownCheckInterval = null;
        }
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        if (this.countdownRestartHandler) {
            document.removeEventListener('migration_countdown_restart', this.countdownRestartHandler);
            this.countdownRestartHandler = null;
        }
    },
});
