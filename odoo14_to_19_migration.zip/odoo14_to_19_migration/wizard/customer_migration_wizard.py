# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError
import logging
import json
import ast
import time

_logger = logging.getLogger(__name__)


class CustomerMigrationWizard(models.TransientModel):
    _name = 'odoo14.customer.migration.wizard'
    _description = 'Customer Migration Wizard'

    config_id = fields.Many2one(
        'odoo14.migration.config',
        string='Migration Configuration',
        required=True,
        help='Select the Odoo 14 connection configuration'
    )
    
    # Customer migration items - Fixed fields for each model
    customers_count = fields.Integer(string='Customers Total Count', default=0, readonly=True)
    customers_migrated = fields.Integer(string='Customers Migrated', default=0, readonly=True)
    
    quotations_count = fields.Integer(string='Quotations Total Count', default=0, readonly=True)
    quotations_migrated = fields.Integer(string='Quotations Migrated', default=0, readonly=True)
    quotations_offset = fields.Integer(string='Quotations Offset', default=0, readonly=True, help='Current offset position for batch processing (includes skipped records)')
    quotations_progress = fields.Float(string='Quotations Progress %', compute='_compute_quotations_progress', store=False)
    
    sales_orders_count = fields.Integer(string='Sales Orders Total Count', default=0, readonly=True)
    sales_orders_migrated = fields.Integer(string='Sales Orders Migrated', default=0, readonly=True)
    
    invoices_count = fields.Integer(string='Invoices Total Count', default=0, readonly=True)
    invoices_migrated = fields.Integer(string='Invoices Migrated', default=0, readonly=True)
    
    migration_status = fields.Text(string='Migration Status', readonly=True)
    is_migrating = fields.Boolean(string='Migration in Progress', default=False, readonly=True)
    auto_continue = fields.Boolean(string='Auto Continue', default=False, readonly=True, help='Enable automatic countdown and continuation')
    countdown_seconds = fields.Integer(string='Countdown (seconds)', default=0, readonly=True, help='Countdown timer before auto-continuing migration')
    
    @api.depends('quotations_count', 'quotations_migrated')
    def _compute_quotations_progress(self):
        for record in self:
            if record.quotations_count > 0:
                record.quotations_progress = (record.quotations_migrated / record.quotations_count) * 100
            else:
                record.quotations_progress = 0.0
    
    # Legacy field for backward compatibility
    customer_items = fields.One2many(
        'odoo14.customer.migration.item',
        'wizard_id',
        string='Customer Items'
    )
    
    def action_check_customers(self):
        """Check customers count"""
        # For Odoo 14, use customer field (boolean)
        # Try multiple approaches: customer=True OR has sale orders
        return self._check_model('customers', 'res.partner', "[('customer', '=', True)]")
    
    def action_check_quotations(self):
        """Check quotations count - all quotations regardless of state"""
        return self._check_model('quotations', 'sale.order', "[]")
    
    def action_check_sales_orders(self):
        """Check sales orders count"""
        return self._check_model('sales_orders', 'sale.order', "[('state', '=', 'sale')]")
    
    def action_check_invoices(self):
        """Check invoices count"""
        return self._check_model('invoices', 'account.invoice', "[('type', '=', 'out_invoice')]")
    
    def _check_model(self, model_type, model_name, domain_str):
        """Check count for a specific model"""
        self.ensure_one()
        if not self.config_id:
            raise UserError('Please select a migration configuration first.')
        
        try:
            from ..models.odoo14_api_client import Odoo14APIClient
            import json
            
            client = Odoo14APIClient(
                url=self.config_id.odoo14_url,
                db=self.config_id.odoo14_database,
                username=self.config_id.odoo14_username,
                password=self.config_id.odoo14_password
            )
            
            if not client.authenticate():
                raise UserError('Failed to authenticate with Odoo 14. Please test the connection first.')
            
            # Use XML-RPC to get count (more reliable than REST API)
            # Parse domain string (it's Python syntax, not JSON)
            if domain_str:
                try:
                    domain = ast.literal_eval(domain_str)
                except:
                    # Fallback to JSON if ast fails
                    try:
                        domain = json.loads(domain_str)
                    except:
                        domain = []
            else:
                domain = []
            
            # For res.partner, first get total partners count
            total_partners = 0
            if model_name == 'res.partner':
                try:
                    total_partners = client.count(model_name, [])
                    _logger.info("Total partners (no domain): %s" % total_partners)
                except Exception as e:
                    _logger.error("Error getting total partners: %s" % str(e))
                    raise UserError('Failed to connect to Odoo 14. Error: %s' % str(e))
            
            # Handle customer field differences between Odoo 14 and 15+
            # Odoo 14 uses 'customer' field (boolean), Odoo 15+ uses 'customer_rank' (integer)
            # But some Odoo 14 instances might not have the 'customer' field
            customer_field_exists = None
            if model_name == 'res.partner' and domain:
                # Check if customer field exists by trying to use it
                customer_field_exists = False
                try:
                    # Try a test search with customer field
                    test_result = client.count(model_name, [('customer', '=', True)])
                    customer_field_exists = True
                    _logger.info("Customer field exists, test count: %s" % test_result)
                except Exception as e:
                    error_str = str(e)
                    if "Invalid field" in error_str or "customer" in error_str.lower():
                        customer_field_exists = False
                        _logger.warning("Customer field does not exist in this Odoo 14 instance")
                        # Use empty domain - we'll use total partners count
                        domain = []
                    else:
                        _logger.error("Error testing customer field: %s" % error_str)
                        raise
                
                if customer_field_exists:
                    # Convert customer_rank domain to customer domain for Odoo 14
                    new_domain = []
                    for d in domain:
                        if d[0] == 'customer_rank' and len(d) == 3:
                            # Convert customer_rank > 0 to customer = True
                            if d[1] in ('>', '>=', '!=') and d[2] > 0:
                                new_domain.append(('customer', '=', True))
                            elif d[1] == '=' and d[2] == 0:
                                new_domain.append(('customer', '=', False))
                            else:
                                new_domain.append(d)
                        elif d[0] == 'customer' and len(d) == 3:
                            # Keep customer domain as is
                            new_domain.append(d)
                        else:
                            new_domain.append(d)
                    domain = new_domain
                
                # Log the domain for debugging
                _logger.info("Using domain for res.partner: %s (customer_field_exists: %s)" % (domain, customer_field_exists))
            
            # Handle account.invoice vs account.move
            if model_name == 'account.invoice':
                invoice_model = client._get_invoice_model()
                if invoice_model:
                    model_name = invoice_model
                    if invoice_model == 'account.move':
                        domain = [d if d[0] != 'type' else ('move_type', d[1], d[2]) for d in domain]
            
            # Get count via XML-RPC
            _logger.info("Getting count for model: %s, domain: %s" % (model_name, domain))
            
            try:
                # If domain is empty for res.partner, it means customer field doesn't exist
                # Use total partners as count
                if model_name == 'res.partner' and not domain:
                    _logger.info("Customer field doesn't exist, using total partners (%s) as customer count" % total_partners)
                    count = total_partners
                else:
                    count = client.count(model_name, domain)
                    _logger.info("XML-RPC count for %s with domain %s: %s" % (model_name, domain, count))
                    
                    # If count is 0 and we have total partners, use total partners
                    if model_name == 'res.partner' and count == 0 and total_partners > 0:
                        _logger.warning("Customer count is 0 but total partners is %s. Using total partners." % total_partners)
                        count = total_partners
                
                # If count is 0 and we're checking customers, try alternative approaches
                if count == 0 and model_name == 'res.partner' and total_partners > 0:
                    _logger.info("Count is 0 but total partners is %s, checking if customer field exists..." % total_partners)
                    
                    # Check if customer field exists by trying to read a partner
                    try:
                        # Get first partner to check fields
                        test_partners = client.search_read(model_name, [], ['name'], limit=1)
                        if test_partners:
                            # Try to read customer field
                            try:
                                test_with_customer = client.search_read(model_name, [], ['customer'], limit=1)
                                _logger.info("Customer field exists in this instance")
                            except:
                                _logger.info("Customer field does NOT exist in this instance")
                                # Use total partners as customer count
                                count = total_partners
                                _logger.info("Using total partners (%s) as customer count" % count)
                    except Exception as e:
                        _logger.error("Error checking partner fields: %s" % str(e))
                        # If we can't check, use total partners as fallback
                        if total_partners > 0:
                            count = total_partners
                            _logger.info("Using total partners (%s) as customer count (fallback)" % count)
                
            except Exception as e:
                error_str = str(e)
                _logger.error("Error getting count via XML-RPC for %s: %s" % (model_name, error_str))
                
                # If error is about invalid customer field and we have total partners, use that
                if model_name == 'res.partner' and ("Invalid field" in error_str or "customer" in error_str.lower()):
                    if total_partners > 0:
                        _logger.info("Customer field error detected, using total partners (%s) as count" % total_partners)
                        count = total_partners
                    else:
                        # Try without domain as fallback
                        try:
                            _logger.info("Trying without domain...")
                            count = client.count(model_name, [])
                            _logger.info("XML-RPC count for %s without domain: %s" % (model_name, count))
                        except Exception as e2:
                            _logger.error("Error even without domain: %s" % str(e2))
                            raise UserError('Failed to get count for %s: %s' % (model_name, str(e)))
                else:
                    # Try without domain as fallback
                    try:
                        _logger.info("Trying without domain...")
                        count = client.count(model_name, [])
                        _logger.info("XML-RPC count for %s without domain: %s" % (model_name, count))
                    except Exception as e2:
                        _logger.error("Error even without domain: %s" % str(e2))
                        raise UserError('Failed to get count for %s: %s' % (model_name, str(e)))
            
            # Update the appropriate field
            field_map = {
                'customers': ('customers_count', 'customers_migrated'),
                'quotations': ('quotations_count', 'quotations_migrated'),
                'sales_orders': ('sales_orders_count', 'sales_orders_migrated'),
                'invoices': ('invoices_count', 'invoices_migrated'),
            }
            
            count_field, _ = field_map.get(model_type, (None, None))
            if count_field:
                self.write({count_field: count})
            
            # Return action to reload the form so buttons become visible when count > 0
            return {
                'type': 'ir.actions.act_window',
                'res_model': self._name,
                'res_id': self.id,
                'view_mode': 'form',
                'target': 'new',
                'views': [(False, 'form')],
            }
        except Exception as e:
            _logger.error("Error checking %s: %s" % (model_type, str(e)))
            raise UserError('Error checking %s: %s' % (model_type, str(e)))
    
    def action_preview_customers(self):
        """Preview customers"""
        self.ensure_one()
        if self.customers_count == 0:
            raise UserError('No customers found. Please check data first.')
        
        if not self.config_id:
            raise UserError('Please select a migration configuration first.')
        
        try:
            from ..models.odoo14_api_client import Odoo14APIClient
            
            client = Odoo14APIClient(
                url=self.config_id.odoo14_url,
                db=self.config_id.odoo14_database,
                username=self.config_id.odoo14_username,
                password=self.config_id.odoo14_password
            )
            
            if not client.authenticate():
                raise UserError('Failed to authenticate with Odoo 14. Please test the connection first.')
            
            # Get first customer
            domain = []
            customers = client.search_read('res.partner', domain, 
                ['name', 'email', 'phone', 'mobile', 'street', 'city', 'country_id'], 
                limit=1, offset=0)
            
            if not customers:
                raise UserError('No customers found to preview.')
            
            # Create preview record
            preview = self.env['odoo14.customer.preview'].create({
                'wizard_id': self.id,
                'config_id': self.config_id.id,
                'current_index': 0,
                'total_count': self.customers_count,
            })
            
            # Load first customer
            preview._load_customer(offset=0)
            
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'odoo14.customer.preview',
                'res_id': preview.id,
                'view_mode': 'form',
                'target': 'new',
                'name': 'Customer Preview (%s of %s)' % (1, self.customers_count),
            }
        except UserError:
            raise
        except Exception as e:
            _logger.error("Error previewing customers: %s" % str(e))
            raise UserError('Error previewing customers: %s' % str(e))
    
    def action_preview_quotations(self):
        """Preview quotations"""
        self.ensure_one()
        if self.quotations_count == 0:
            raise UserError('No quotations found. Please check data first.')
        
        if not self.config_id:
            raise UserError('Please select a migration configuration first.')
        
        try:
            from ..models.odoo14_api_client import Odoo14APIClient
            
            client = Odoo14APIClient(
                url=self.config_id.odoo14_url,
                db=self.config_id.odoo14_database,
                username=self.config_id.odoo14_username,
                password=self.config_id.odoo14_password
            )
            
            if not client.authenticate():
                raise UserError('Failed to authenticate with Odoo 14. Please test the connection first.')
            
            # Create preview record
            preview = self.env['odoo14.quotation.preview'].create({
                'wizard_id': self.id,
                'config_id': self.config_id.id,
                'current_index': 0,
                'total_count': self.quotations_count,
            })
            
            # Load first quotation
            preview._load_quotation(offset=0)
            
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'odoo14.quotation.preview',
                'res_id': preview.id,
                'view_mode': 'form',
                'target': 'new',
                'name': 'Quotation Preview (%s of %s)' % (1, self.quotations_count),
            }
        except UserError:
            raise
        except Exception as e:
            _logger.error("Error previewing quotations: %s" % str(e))
            raise UserError('Error previewing quotations: %s' % str(e))
    
    def action_preview_sales_orders(self):
        """Preview sales orders"""
        if self.sales_orders_count == 0:
            raise UserError('No sales orders found. Please check data first.')
        # TODO: Implement preview
        return {'type': 'ir.actions.act_window_close'}
    
    def action_preview_invoices(self):
        """Preview invoices"""
        if self.invoices_count == 0:
            raise UserError('No invoices found. Please check data first.')
        # TODO: Implement preview
        return {'type': 'ir.actions.act_window_close'}
    
    def action_migrate_customers(self):
        """Migrate customers from Odoo 14 to Odoo 19"""
        self.ensure_one()
        if self.customers_count == 0:
            raise UserError('No customers found. Please check data first.')
        
        if not self.config_id:
            raise UserError('Please select a migration configuration first.')
        
        try:
            from ..models.odoo14_api_client import Odoo14APIClient
            
            client = Odoo14APIClient(
                url=self.config_id.odoo14_url,
                db=self.config_id.odoo14_database,
                username=self.config_id.odoo14_username,
                password=self.config_id.odoo14_password
            )
            
            if not client.authenticate():
                raise UserError('Failed to authenticate with Odoo 14. Please test the connection first.')
            
            # Get all customers from Odoo 14
            domain = []
            customers = client.search_read('res.partner', domain, 
                ['name', 'email', 'phone', 'mobile', 'street', 'street2', 'city', 
                 'state_id', 'zip', 'country_id', 'vat', 'is_company'], 
                limit=self.customers_count, offset=0)
            
            if not customers:
                raise UserError('No customers found to migrate.')
            
            migrated = 0
            skipped = 0
            errors = 0
            
            # Migrate customers in batches
            batch_size = 50
            for i in range(0, len(customers), batch_size):
                batch = customers[i:i+batch_size]
                
                for customer_data in batch:
                    try:
                        # Check for duplicates
                        name = customer_data.get('name', '').strip()
                        email = customer_data.get('email', '').strip() if customer_data.get('email') else ''
                        vat = customer_data.get('vat', '').strip() if customer_data.get('vat') else ''
                        
                        # Search for existing customer by name first (most reliable)
                        existing = False
                        if name:
                            existing = self.env['res.partner'].search([
                                ('name', '=', name)
                            ], limit=1)
                        
                        # If not found by name, check by email or VAT
                        if not existing:
                            search_domain = []
                            if email:
                                search_domain.append(('email', '=', email))
                            if vat:
                                search_domain.append(('vat', '=', vat))
                            
                            if search_domain:
                                if len(search_domain) == 2:
                                    # Both email and VAT - use OR
                                    search_domain = ['|'] + search_domain
                                existing = self.env['res.partner'].search(search_domain, limit=1)
                        
                        if existing:
                            skipped += 1
                            _logger.info("Skipping duplicate customer: %s (found existing: %s)" % (name, existing.name))
                            continue
                        
                        # Create customer
                        partner_vals = self._prepare_customer_vals(customer_data)
                        self.env['res.partner'].create(partner_vals)
                        migrated += 1
                        
                        # Update progress every 10 records
                        if migrated % 10 == 0:
                            self.write({'customers_migrated': migrated})
                            self.env.cr.commit()
                            _logger.info("Progress: Migrated %s/%s customers" % (migrated, len(customers)))
                    
                    except Exception as e:
                        errors += 1
                        _logger.error("Error migrating customer %s: %s" % (customer_data.get('name', 'Unknown'), str(e)))
                        continue
                
                # Update progress after each batch
                self.write({'customers_migrated': migrated})
                self.env.cr.commit()
            
            # Final update
            self.write({'customers_migrated': migrated})
            self.env.cr.commit()
            
            message = 'Migration complete! Migrated: %s, Skipped (duplicates): %s, Errors: %s' % (migrated, skipped, errors)
            
            # Reload form to show updated count (keep popup open)
            return {
                'type': 'ir.actions.act_window',
                'res_model': self._name,
                'res_id': self.id,
                'view_mode': 'form',
                'target': 'new',
                'views': [(False, 'form')],
                'context': {
                    'migration_message': message,
                    'migration_migrated': migrated,
                    'migration_skipped': skipped,
                    'migration_errors': errors,
                }
            }
        except UserError:
            raise
        except Exception as e:
            _logger.error("Error migrating customers: %s" % str(e))
            raise UserError('Error migrating customers: %s' % str(e))
    
    def _prepare_customer_vals(self, customer_data):
        """Prepare customer values for creation"""
        # Handle country
        country = False
        country_id = customer_data.get('country_id')
        if country_id:
            country_id_val = country_id[0] if isinstance(country_id, list) else country_id
            if country_id_val:
                country = self.env['res.country'].browse(country_id_val)
                if not country.exists():
                    country = False
        
        # Handle state with cleaning
        state = False
        state_id = customer_data.get('state_id')
        if state_id:
            state_id_val = state_id[0] if isinstance(state_id, list) else state_id
            state_name = state_id[1] if isinstance(state_id, list) and len(state_id) > 1 else ''
            
            if state_id_val:
                state = self.env['res.country.state'].browse(state_id_val)
                if state.exists():
                    # Clean state name: remove (AE) and capitalize
                    if state_name:
                        cleaned_name = state_name.replace('(AE)', '').replace('(ae)', '').strip()
                        cleaned_name = ' '.join(word.capitalize() for word in cleaned_name.split())
                        # Update state name if it contains (AE)
                        if '(AE)' in state.name or '(ae)' in state.name:
                            state.write({'name': cleaned_name})
                else:
                    state = False
        
        # Build partner values, only including fields that exist in the model
        partner_vals = {
            'name': customer_data.get('name', ''),
            'email': customer_data.get('email', '') or False,
            'phone': customer_data.get('phone', '') or False,
            'street': customer_data.get('street', '') or False,
            'street2': customer_data.get('street2', '') or False,
            'city': customer_data.get('city', '') or False,
            'state_id': state.id if state else False,
            'zip': customer_data.get('zip', '') or False,
            'country_id': country.id if country else False,
            'vat': customer_data.get('vat', '') or False,
            'is_company': customer_data.get('is_company', False),
            'customer_rank': 1,  # Set as customer
        }
        
        # Only add mobile if the field exists in res.partner
        # Check if mobile field exists before adding it
        if 'mobile' in self.env['res.partner']._fields:
            mobile_value = customer_data.get('mobile', '') or False
            if mobile_value:
                partner_vals['mobile'] = mobile_value
        
        return partner_vals
    
    def action_migrate_quotations(self):
        """Migrate quotations from Odoo 14 to Odoo 19 - processes in batches with auto-continue"""
        self.ensure_one()
        if self.quotations_count == 0:
            raise UserError('No quotations found. Please check data first.')

        if not self.config_id:
            raise UserError('Please select a migration configuration first.')

        # Check if we're resuming migration or starting new
        # Use quotations_offset if available (tracks position including skipped), otherwise use migrated count
        # Handle case where quotations_offset field might not exist yet (during module upgrade)
        if 'quotations_offset' in self._fields and self.quotations_offset > 0:
            offset = self.quotations_offset
        else:
            offset = self.quotations_migrated

        # Set migration in progress flag (if not already set)
        if not self.is_migrating:
            self.write({
                'is_migrating': True,
                'auto_continue': False,  # Reset auto-continue when starting
                'countdown_seconds': 0,  # Reset countdown when starting
                'migration_status': f'Starting migration... (Resuming from {offset})' if offset > 0 else 'Starting migration...',
            })
            self.env.cr.commit()

        try:
            from ..models.odoo14_api_client import Odoo14APIClient

            client = Odoo14APIClient(
                url=self.config_id.odoo14_url,
                db=self.config_id.odoo14_database,
                username=self.config_id.odoo14_username,
                password=self.config_id.odoo14_password
            )

            if not client.authenticate():
                raise UserError('Failed to authenticate with Odoo 14. Please test the connection first.')

            domain = []

            default_fields = [
                'name', 'partner_id', 'date_order', 'validity_date', 'amount_total',
                'amount_untaxed', 'amount_tax', 'state', 'pricelist_id', 'payment_term_id',
                'order_line', 'note', 'client_order_ref', 'user_id', 'team_id', 'company_id'
            ]

            fields_to_fetch = default_fields.copy()
            try:
                all_fields = client.fields_get('sale.order')
                if all_fields:
                    problematic_fields = ['due_amount', 'credit', 'debit', 'invoice_ids', 'invoice_count']
                    dynamic_fields = []
                    for f, field_info in all_fields.items():
                        field_type = field_info.get('type', '')
                        field_store = field_info.get('store', True)
                        if field_type in ('one2many', 'many2many') and f != 'order_line':
                            continue
                        if f in problematic_fields:
                            continue
                        if (not field_store and field_type not in ('char', 'text', 'integer', 'float', 'boolean', 'date', 'datetime')):
                            continue
                        dynamic_fields.append(f)
                    fields_to_fetch = list(set(fields_to_fetch + dynamic_fields))
                    _logger.info("Retrieved %s fields for sale.order migration (excluding problematic computed fields)", len(fields_to_fetch))
            except Exception as e:
                _logger.warning("Could not get all fields for migration using fields_get, using default set: %s", str(e))

            batch_size = 10  # reduced batch size to avoid timeout issues

            # Fetch batch with retry to handle transient connection errors
            quotations = []
            max_attempts = 5  # Increased retries for connection issues
            last_error = None
            for attempt in range(1, max_attempts + 1):
                try:
                    _logger.info("Fetching batch: offset=%s, limit=%s, attempt=%s/%s", offset, batch_size, attempt, max_attempts)
                    quotations = client.search_read(
                        'sale.order',
                        domain,
                        fields_to_fetch,
                        limit=batch_size,
                        offset=offset,
                        order='id'
                    )
                    _logger.info("Successfully fetched %s quotations", len(quotations))
                    break
                except Exception as e:
                    last_error = e
                    error_msg = str(e)
                    _logger.warning("search_read attempt %s/%s failed for sale.order offset %s: %s", attempt, max_attempts, offset, error_msg)
                    
                    if attempt >= max_attempts:
                        # Save current progress before raising error
                        self.write({
                            'migration_status': f'Connection error at offset {offset}. Progress saved: {offset}/{self.quotations_count}. Please retry.',
                        })
                        self.env.cr.commit()
                        raise UserError(f'Failed to fetch quotations after {max_attempts} attempts. Last error: {error_msg}. Progress saved at {offset}/{self.quotations_count}. Please click "Continue Migration" to retry.')
                    
                    # Exponential backoff: 1s, 2s, 3s, 4s
                    wait_time = attempt
                    _logger.info("Waiting %s seconds before retry...", wait_time)
                    time.sleep(wait_time)
                    
                    # Try to re-authenticate if connection was lost
                    try:
                        if not client.authenticate():
                            _logger.warning("Re-authentication failed on attempt %s", attempt)
                    except Exception as auth_error:
                        _logger.warning("Re-authentication error: %s", str(auth_error))

            if not quotations:
                self.write({
                    'is_migrating': False,
                    'migration_status': 'Migration complete! All quotations migrated.',
                })
                self.env.cr.commit()
                return self.action_refresh_view(notification_message='All quotations have been migrated.')

            migrated = 0
            skipped = 0
            errors = 0

            self.write({
                'migration_status': f'Migrating batch... ({offset}/{self.quotations_count})',
            })
            self.env.cr.commit()

            for idx, quotation_data in enumerate(quotations):
                try:
                    quotation_name = quotation_data.get('name', '').strip()

                    if quotation_name:
                        existing = self.env['sale.order'].search([('name', '=', quotation_name)], limit=1)
                        if existing:
                            skipped += 1
                            _logger.info("Skipping duplicate quotation: %s", quotation_name)
                            # Still update progress even for skipped records
                            current_total = offset + migrated + skipped
                            if current_total % 5 == 0:  # Update every 5 records to reduce DB load
                                self.write({
                                    'quotations_migrated': current_total - skipped,  # Only count migrated, not skipped
                                    'migration_status': f'Migrating... ({current_total - skipped}/{self.quotations_count}) - Skipped: {skipped}',
                                })
                                self.env.cr.commit()
                            continue

                    quotation_vals = self._prepare_quotation_vals(quotation_data, client)
                    quotation = self.env['sale.order'].create(quotation_vals)
                    
                    # Create lines with batched product lookups (optimized)
                    try:
                        self._create_quotation_lines(quotation, quotation_data, client)
                    except Exception as line_error:
                        _logger.warning("Error creating quotation lines for %s: %s. Continuing with quotation only.", quotation_name, str(line_error))
                        # Continue even if lines fail - quotation is created

                    # Commit after each record to ensure progress is saved
                    self.env.cr.commit()
                    migrated += 1

                    current_total = offset + migrated
                    progress_percent = (current_total / self.quotations_count * 100) if self.quotations_count > 0 else 0
                    
                    # Update progress after each record to ensure UI shows correct count
                    progress_vals = {
                        'quotations_migrated': current_total,
                        'migration_status': f'Migrating... ({current_total}/{self.quotations_count}) - {progress_percent:.1f}%',
                    }
                    self.write(progress_vals)
                    self.env.cr.commit()
                    _logger.info("Progress: Migrated %s/%s quotations (%.1f%%)", current_total, self.quotations_count, progress_percent)

                except Exception as e:
                    try:
                        if not self.env.cr.closed:
                            self.env.cr.rollback()
                    except Exception as rollback_error:
                        _logger.error("Error during rollback: %s", str(rollback_error))
                        try:
                            self.env.registry.clear_cache()
                        except Exception:
                            pass

                    errors += 1
                    error_msg = str(e)
                    _logger.error("Error migrating quotation %s: %s", quotation_data.get('name', 'Unknown'), error_msg)
                    
                    # If connection error, break and let retry logic handle it
                    if 'Connection' in error_msg or 'connection' in error_msg.lower() or 'timeout' in error_msg.lower():
                        _logger.warning("Connection error detected. Stopping batch to allow retry.")
                        break  # Break out of loop to allow retry
                    
                    continue

            # Calculate totals: migrated count for display, processed count for offset
            # migrated_total = previous migrated count + newly migrated in this batch
            previous_migrated = self.quotations_migrated
            migrated_total = previous_migrated + migrated  # Total successfully migrated (cumulative)
            processed_total = offset + migrated + skipped  # Total processed (for next batch offset)
            progress_percent = (migrated_total / self.quotations_count * 100) if self.quotations_count > 0 else 0

            # Always save progress, even if batch had errors
            # This ensures migrated count is never lost
            try:
                # Prepare write values - only include quotations_offset if field exists
                progress_vals = {
                    'quotations_migrated': migrated_total,  # Only count successfully migrated (for display)
                    'is_migrating': True,
                    'migration_status': f'Batch processed: {migrated} migrated, {skipped} skipped, {errors} errors. Total migrated: {migrated_total}/{self.quotations_count}',
                }
                # Only add quotations_offset if the field exists (for backward compatibility during upgrade)
                if 'quotations_offset' in self._fields:
                    progress_vals['quotations_offset'] = processed_total
                
                self.write(progress_vals)
                self.env.cr.commit()
                _logger.info("Progress saved: %s/%s quotations migrated (migrated=%s, skipped=%s, errors=%s, offset=%s)", 
                            migrated_total, self.quotations_count, migrated, skipped, errors, processed_total)
            except Exception as save_error:
                _logger.error("Error saving progress: %s", str(save_error))
                # Try to commit anyway
                try:
                    self.env.cr.commit()
                except:
                    pass

            # If batch had connection errors and nothing was migrated, retry same batch
            if migrated == 0 and errors > 0:
                _logger.warning("Batch failed: migrated=0, errors=%s. Retrying from offset %s...", errors, offset)
                self.write({
                    'migration_status': f'Connection error. Retrying batch from offset {offset}... (Progress: {current_total}/{self.quotations_count})',
                    'auto_continue': False,  # Disable auto-continue on error
                    'countdown_seconds': 0,
                })
                self.env.cr.commit()
                # Return to retry same batch
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': self._name,
                    'res_id': self.id,
                    'view_mode': 'form',
                    'target': 'new',
                    'views': [(False, 'form')],
                }

            if processed_total >= self.quotations_count:
                self.write({
                    'quotations_migrated': migrated_total,
                    'is_migrating': False,
                    'auto_continue': False,  # Disable auto-continue when complete
                    'countdown_seconds': 0,  # Reset countdown when complete
                    'migration_status': f'Migration complete! Migrated: {migrated_total}, Skipped: {skipped}, Errors: {errors}',
                })
                self.env.cr.commit()
                _logger.info("Migration complete: %s/%s quotations migrated", migrated_total, self.quotations_count)

                message = f'Migration complete! Migrated: {migrated_total}, Skipped (duplicates): {skipped}, Errors: {errors}'
                return self.action_refresh_view(notification_message=message)

            # Enable auto countdown for next batch
            # quotations_offset is already updated above with processed_total
            self.write({
                'is_migrating': True,
                'auto_continue': True,  # Enable auto-continue countdown
                'countdown_seconds': 5,  # Start 5-second countdown
                'migration_status': f'Migrated batch: {migrated_total}/{self.quotations_count} ({progress_percent:.1f}%) - Continuing...',
            })
            self.env.cr.commit()
            _logger.info("Batch complete: %s/%s quotations migrated (migrated=%s, skipped=%s, errors=%s). Next offset: %s. Starting 5-second countdown.", 
                        migrated_total, self.quotations_count, migrated, skipped, errors, processed_total)

            return {
                'type': 'ir.actions.act_window',
                'res_model': self._name,
                'res_id': self.id,
                'view_mode': 'form',
                'target': 'new',
                'views': [(False, 'form')],
                # Hint to JS/next load to keep auto-continue going without manual clicks
                'context': dict(self.env.context, auto_continue_migration=True),
            }

        except UserError:
            raise
        except Exception as e:
            self.write({
                'is_migrating': False,
                'migration_status': f'Migration error: {str(e)}',
            })
            self.env.cr.commit()
            _logger.error("Error migrating quotations: %s", str(e))
            raise UserError('Error migrating quotations: %s' % str(e))
    
    def action_refresh_view(self, notification_message=None):
        """Refresh the view to show updated progress and optionally display a notification"""
        action = {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            'views': [(False, 'form')],
        }
        if notification_message:
            action['effect'] = {
                'fadeout': 'slow',
                'message': notification_message,
                'type': 'rainbow_man',
            }
        return action
    
    @api.model
    def default_get(self, fields_list):
        """Handle auto-continue migration flag from context"""
        res = super().default_get(fields_list)
        # Check if we should auto-continue migration
        if self.env.context.get('auto_continue_migration'):
            # Schedule migration continuation after a short delay
            # This will be handled by JavaScript
            pass
        return res
    
    def _find_or_create_contact_partner(self, contact_name, parent_partner, contact_type='Contact'):
        """Find or create a contact partner (child of parent_partner)"""
        if not contact_name or not parent_partner:
            return False
        
        # Search for existing contact with same name under parent
        existing = self.env['res.partner'].search([
            ('name', '=', contact_name),
            ('parent_id', '=', parent_partner.id),
            ('is_company', '=', False)
        ], limit=1)
        
        if existing:
            return existing
        
        # Create new contact
        try:
            contact = self.env['res.partner'].create({
                'name': contact_name,
                'parent_id': parent_partner.id,
                'is_company': False,
            })
            _logger.info("Created %s contact: %s (parent: %s)" % (contact_type, contact_name, parent_partner.name))
            return contact
        except Exception as e:
            _logger.warning("Error creating %s contact %s: %s" % (contact_type, contact_name, str(e)))
            return False
    
    def _find_or_create_partner_by_name(self, partner_name):
        """Find or create a partner by name"""
        if not partner_name:
            return False
        
        # Search for existing partner
        existing = self.env['res.partner'].search([
            ('name', '=', partner_name)
        ], limit=1)
        
        if existing:
            return existing
        
        # Create new partner
        try:
            partner = self.env['res.partner'].create({
                'name': partner_name,
                'is_company': False,  # Default to individual
            })
            _logger.info("Created partner: %s" % partner_name)
            return partner
        except Exception as e:
            _logger.warning("Error creating partner %s: %s" % (partner_name, str(e)))
            return False
    
    def _prepare_quotation_vals(self, quotation_data, client):
        """Prepare quotation values for creation"""
        # Get or create partner - REQUIRED for quotation
        partner = False
        partner_id = quotation_data.get('partner_id')
        if partner_id:
            partner_id_val = partner_id[0] if isinstance(partner_id, list) else partner_id
            partner_name = partner_id[1] if isinstance(partner_id, list) and len(partner_id) > 1 else ''
            
            if partner_id_val:
                try:
                    # First try to find by ID
                    partner = self.env['res.partner'].browse(partner_id_val)
                    if not partner.exists():
                        partner = False
                except:
                    partner = False
                
                # If not found by ID, try by name
                if not partner and partner_name:
                    try:
                        partner = self.env['res.partner'].search([
                            ('name', '=', partner_name)
                        ], limit=1)
                    except Exception as e:
                        _logger.warning("Error searching for partner by name %s: %s" % (partner_name, str(e)))
                        partner = False
                
                # If still not found, try to get from Odoo 14 and create
                if not partner:
                    try:
                        partner_data = client.get_partner(partner_id_val)
                        if partner_data:
                            # Use the same logic as customer migration
                            partner_vals = self._prepare_customer_vals(partner_data)
                            partner = self.env['res.partner'].create(partner_vals)
                    except Exception as e:
                        _logger.warning("Error creating partner %s: %s" % (partner_id_val, str(e)))
                        partner = False
        
        # Partner is REQUIRED - if we don't have one, we can't create the quotation
        if not partner:
            raise ValueError("Partner is required but not found or could not be created for quotation %s" % quotation_data.get('name', 'Unknown'))
        
        # Get pricelist
        pricelist = False
        pricelist_id = quotation_data.get('pricelist_id')
        if pricelist_id:
            pricelist_id_val = pricelist_id[0] if isinstance(pricelist_id, list) else pricelist_id
            if pricelist_id_val:
                pricelist = self.env['product.pricelist'].browse(pricelist_id_val)
                if not pricelist.exists():
                    pricelist = False
        
        # Get payment terms
        payment_term = False
        payment_term_id = quotation_data.get('payment_term_id')
        if payment_term_id:
            payment_term_id_val = payment_term_id[0] if isinstance(payment_term_id, list) else payment_term_id
            if payment_term_id_val:
                payment_term = self.env['account.payment.term'].browse(payment_term_id_val)
                if not payment_term.exists():
                    payment_term = False
        
        # Standard fields
        # In Odoo 19, partner_invoice_id and partner_shipping_id are required (NOT NULL)
        # We already checked that partner exists above, so partner.id should be valid
        partner_id_val = partner.id
        
        quotation_vals = {
            'name': quotation_data.get('name', ''),
            'partner_id': partner_id_val,
            'partner_invoice_id': partner_id_val,  # Required in Odoo 19 - always use partner_id
            'partner_shipping_id': partner_id_val,  # Required in Odoo 19 - always use partner_id
            'date_order': quotation_data.get('date_order', False),
            'validity_date': quotation_data.get('validity_date', False),
            'pricelist_id': pricelist.id if pricelist else False,
            'payment_term_id': payment_term.id if payment_term else False,
            'state': 'draft',  # Always create as draft
            'client_order_ref': quotation_data.get('client_order_ref', ''),
            'note': quotation_data.get('note', ''),
        }
        
        # Override with specific invoice/shipping addresses if provided in quotation data
        # But ensure we always have a valid value (fallback to partner_id if override fails)
        if quotation_data.get('partner_invoice_id'):
            invoice_partner_id = quotation_data.get('partner_invoice_id')
            invoice_partner_id_val = invoice_partner_id[0] if isinstance(invoice_partner_id, list) else invoice_partner_id
            if invoice_partner_id_val:
                invoice_partner = self.env['res.partner'].browse(invoice_partner_id_val)
                if invoice_partner.exists():
                    quotation_vals['partner_invoice_id'] = invoice_partner_id_val
                # If override partner doesn't exist, keep the default (partner_id_val)
        
        if quotation_data.get('partner_shipping_id'):
            shipping_partner_id = quotation_data.get('partner_shipping_id')
            shipping_partner_id_val = shipping_partner_id[0] if isinstance(shipping_partner_id, list) else shipping_partner_id
            if shipping_partner_id_val:
                shipping_partner = self.env['res.partner'].browse(shipping_partner_id_val)
                if shipping_partner.exists():
                    quotation_vals['partner_shipping_id'] = shipping_partner_id_val
                # If override partner doesn't exist, keep the default (partner_id_val)
        
        # Final safety check - ensure both are set (should never be False at this point)
        if not quotation_vals.get('partner_invoice_id'):
            quotation_vals['partner_invoice_id'] = partner_id_val
        if not quotation_vals.get('partner_shipping_id'):
            quotation_vals['partner_shipping_id'] = partner_id_val
        
        # ====================================================================
        # FIELD MAPPING STRATEGY: Odoo 14 → Odoo 19
        # Based on discussion: Skip non-critical fields, handle during migration
        # ====================================================================
        
        # Field name mappings (Odoo 14 → Odoo 19)
        FIELD_MAPPINGS = {
            'is_direct_order': 'direct_order',
            'is_lumpsum': 'lumpsum',
            'is_with_stamp': 'with_stamp',
            'is_with_unit_price': 'with_unit_price',
            'is_with_uom': 'with_uom',
            'is_brand': 'with_brand',
            'attention': 'attention_id',  # Char → Many2one (needs lookup)
            'client': 'client_id',  # Char → Many2one (needs lookup)
            'consultants': 'consultants_ids',  # Char → Many2many (needs lookup)
            'regards': 'thanks_and_regards',
        }
        
        # Fields to skip (non-critical, handle during migration if needed)
        SKIP_FIELDS = [
            'project_name', 'scope_of_work', 'engineer_name', 'effective_date',
            'safety_hse_quality', 'is_warning', 'is_tax_include', 'is_reverse',
            'has_due', 'require_payment', 'show_update_pricelist', 'quotation_reverse',
            'medium_id', 'reference_drawing', 'signature', 'sale_order_option_ids',
            'date_start', 'lock_sale',  # May be standard fields
        ]
        
        # Critical fields that should be migrated (5 fields)
        CRITICAL_FIELDS = ['contract_id', 'branch_id', 'source_id', 'sale_oder_type', 'currency_rate']
        
        # Apply field name mappings first
        mapped_quotation_data = {}
        for key, value in quotation_data.items():
            if key in FIELD_MAPPINGS:
                # Map to new field name
                new_key = FIELD_MAPPINGS[key]
                mapped_quotation_data[new_key] = value
                _logger.info("Mapped field %s → %s" % (key, new_key))
            elif key in SKIP_FIELDS:
                # Skip non-critical fields
                _logger.debug("Skipping non-critical field: %s" % key)
                continue
            else:
                # Keep original field name
                mapped_quotation_data[key] = value
        
        # Handle Char → Many2one conversions (attention, client, consultants)
        # These need partner lookup/create logic
        if 'attention_id' in mapped_quotation_data and mapped_quotation_data['attention_id']:
            attention_value = mapped_quotation_data['attention_id']
            if isinstance(attention_value, str):
                # Find or create partner contact
                attention_partner = self._find_or_create_contact_partner(
                    attention_value, partner, 'Attention'
                )
                mapped_quotation_data['attention_id'] = attention_partner.id if attention_partner else False
        
        if 'client_id' in mapped_quotation_data and mapped_quotation_data['client_id']:
            client_value = mapped_quotation_data['client_id']
            if isinstance(client_value, str):
                # Find or create partner
                client_partner = self._find_or_create_partner_by_name(client_value)
                mapped_quotation_data['client_id'] = client_partner.id if client_partner else False
        
        if 'consultants_ids' in mapped_quotation_data and mapped_quotation_data['consultants_ids']:
            consultants_value = mapped_quotation_data['consultants_ids']
            if isinstance(consultants_value, str):
                # Split by comma and find/create partners
                consultant_names = [name.strip() for name in consultants_value.split(',') if name.strip()]
                consultant_ids = []
                for name in consultant_names:
                    consultant_partner = self._find_or_create_partner_by_name(name)
                    if consultant_partner:
                        consultant_ids.append(consultant_partner.id)
                mapped_quotation_data['consultants_ids'] = [(6, 0, consultant_ids)] if consultant_ids else [(5, 0, 0)]
        
        # Use mapped data for further processing
        quotation_data = mapped_quotation_data
        
        # Add all custom fields (fields not in standard list)
        # Include fields from fm_amc_crm_custom and fm_amc_estimation modules
        standard_field_names = [
            'id', 'name', 'partner_id', 'date_order', 'validity_date',
            'pricelist_id', 'payment_term_id', 'order_line', 'note',
            'client_order_ref', 'state', 'amount_total', 'amount_untaxed',
            'amount_tax', 'user_id', 'team_id', 'company_id',
            'create_date', 'write_date', 'create_uid', 'write_uid',
            '__last_update',
            # Required fields that should not be overwritten by custom field processing
            'partner_invoice_id', 'partner_shipping_id',  # Required in Odoo 19, already set above
            # Computed fields that should be skipped (from fm_amc_crm_custom)
            'estimated_value',  # Computed, not stored
            'is_draft_stage', 'is_pending_approval_stage', 'is_quotation_stage',
            'is_quotation_sent_stage', 'is_sales_order_stage', 'is_declined_stage',
            'is_cancelled_stage', 'is_locked',  # All computed, not stored
        ]
        
        # Add custom fields to quotation_vals (from fm_amc_crm_custom, fm_amc_estimation, etc.)
        # Only include fields that exist in Odoo 19 and are not computed/readonly
        sale_order_fields = self.env['sale.order']._fields
        for key, value in quotation_data.items():
            if key not in standard_field_names and not key.startswith('__'):
                # Check if field exists in Odoo 19
                if key not in sale_order_fields:
                    if key in CRITICAL_FIELDS:
                        # Warn if critical field doesn't exist in Odoo 19
                        _logger.warning("CRITICAL FIELD MISSING in Odoo 19: %s. Please ensure this field is created before migration." % key)
                    else:
                        # Skip fields that don't exist in Odoo 19 (non-critical)
                        _logger.debug("Field %s does not exist in Odoo 19, skipping (non-critical)" % key)
                    continue  # Skip this field
                
                # Log critical fields migration
                if key in CRITICAL_FIELDS:
                    _logger.info("Migrating critical field: %s = %s" % (key, value))
                
                field = sale_order_fields[key]
                
                # Skip computed fields that are not stored
                if hasattr(field, 'compute') and field.compute and not field.store:
                    continue
                
                # Skip readonly fields
                if hasattr(field, 'readonly') and field.readonly:
                    continue
                
                try:
                    # Handle Many2one fields (convert from [id, name] to id)
                    if field.type == 'many2one':
                        if isinstance(value, list) and len(value) > 0:
                            # Check if the related record exists
                            related_model = self.env[field.comodel_name]
                            related_id = value[0] if value[0] else False
                            if related_id and related_model.browse(related_id).exists():
                                quotation_vals[key] = related_id
                            else:
                                quotation_vals[key] = False
                        elif not value:
                            quotation_vals[key] = False
                        else:
                            quotation_vals[key] = value
                    # Handle Many2many fields (e.g., consultants_ids from fm_amc_crm_custom)
                    elif field.type == 'many2many':
                        if isinstance(value, list) and value:
                            # Extract IDs from Many2many format: [(6, 0, [ids])] or [id1, id2, ...]
                            many2many_ids = []
                            for item in value:
                                if isinstance(item, (list, tuple)) and len(item) >= 3:
                                    # Format: (6, 0, [ids])
                                    if item[0] == 6 and isinstance(item[2], list):
                                        many2many_ids.extend(item[2])
                                    elif item[0] == 4:  # Link existing
                                        many2many_ids.append(item[1])
                                    elif item[0] == 5:  # Unlink all
                                        many2many_ids = []
                                elif isinstance(item, int):
                                    many2many_ids.append(item)
                            
                            # Check if all IDs exist in target model
                            if many2many_ids:
                                related_model = self.env[field.comodel_name]
                                existing_ids = related_model.browse(many2many_ids).exists().ids
                                if existing_ids:
                                    quotation_vals[key] = [(6, 0, existing_ids)]
                                else:
                                    quotation_vals[key] = [(5, 0, 0)]  # Unlink all if none exist
                            else:
                                quotation_vals[key] = [(5, 0, 0)]  # Unlink all
                        else:
                            quotation_vals[key] = [(5, 0, 0)]  # Unlink all if empty
                    # Handle One2many fields - skip (already handled separately)
                    elif field.type == 'one2many':
                        continue
                    # Handle text fields
                    elif field.type in ('char', 'text', 'html'):
                        if value:
                            quotation_vals[key] = str(value) if value else False
                        else:
                            quotation_vals[key] = False
                    # Handle numeric fields
                    elif field.type in ('integer', 'float'):
                        if value is not None:
                            try:
                                quotation_vals[key] = float(value) if field.type == 'float' else int(value)
                            except (ValueError, TypeError):
                                quotation_vals[key] = 0 if field.type == 'integer' else 0.0
                        else:
                            quotation_vals[key] = 0 if field.type == 'integer' else 0.0
                    # Handle boolean fields
                    elif field.type == 'boolean':
                        quotation_vals[key] = bool(value) if value else False
                    # Handle date fields
                    elif field.type == 'date':
                        if value:
                            quotation_vals[key] = value
                        else:
                            quotation_vals[key] = False
                    # Handle datetime fields
                    elif field.type == 'datetime':
                        if value:
                            quotation_vals[key] = value
                        else:
                            quotation_vals[key] = False
                    # Handle selection fields
                    elif field.type == 'selection':
                        if value and value in [sel[0] for sel in (field.selection or [])]:
                            quotation_vals[key] = value
                    # Handle other field types
                    else:
                        quotation_vals[key] = value
                except Exception as e:
                    # Skip field if there's an error setting it
                    _logger.warning("Skipping field %s due to error: %s" % (key, str(e)))
                    continue
        
        # Final safety check - ensure required fields are always set (protect against overwrites)
        # This is critical because partner_invoice_id and partner_shipping_id are NOT NULL in Odoo 19
        if not quotation_vals.get('partner_invoice_id') or quotation_vals.get('partner_invoice_id') is False:
            quotation_vals['partner_invoice_id'] = partner_id_val
            _logger.warning("partner_invoice_id was missing/False, setting to partner_id: %s" % partner_id_val)
        if not quotation_vals.get('partner_shipping_id') or quotation_vals.get('partner_shipping_id') is False:
            quotation_vals['partner_shipping_id'] = partner_id_val
            _logger.warning("partner_shipping_id was missing/False, setting to partner_id: %s" % partner_id_val)
        
        return quotation_vals
    
    def _create_quotation_lines(self, quotation, quotation_data, client):
        """Create order lines for quotation - optimized with batched product lookups"""
        order_line_ids = quotation_data.get('order_line', [])
        if not order_line_ids:
            return
        
        # Get order line IDs
        line_ids = []
        for line_id in order_line_ids:
            if isinstance(line_id, int):
                line_ids.append(line_id)
            elif isinstance(line_id, (list, tuple)) and len(line_id) > 0:
                line_ids.append(line_id[0])
        
        if not line_ids:
            return
        
        # Fetch order lines data
        try:
            order_lines_data = client.read('sale.order.line', line_ids, [
                'product_id', 'name', 'product_uom_qty', 'product_uom', 
                'price_unit', 'discount', 'tax_id', 'sequence', 'display_type'
            ])
        except Exception as e:
            _logger.error("Error fetching order lines: %s", str(e))
            return
        
        # Batch collect all product IDs that need to be fetched
        product_ids_to_fetch = []
        product_id_map = {}  # Maps Odoo 14 product ID to line data
        
        for line_data in order_lines_data:
            # Skip section/note lines
            if line_data.get('display_type') in ('line_section', 'line_note'):
                continue
            
            product_id = line_data.get('product_id')
            if product_id:
                product_id_val = product_id[0] if isinstance(product_id, list) else product_id
                if product_id_val:
                    # Check if product exists in Odoo 19
                    product = self.env['product.product'].browse(product_id_val)
                    if not product.exists():
                        # Need to fetch from Odoo 14
                        if product_id_val not in product_ids_to_fetch:
                            product_ids_to_fetch.append(product_id_val)
                        product_id_map[product_id_val] = line_data
        
        # Batch fetch all products from Odoo 14 in one call
        products_data_map = {}
        if product_ids_to_fetch:
            try:
                _logger.info("Batch fetching %s products from Odoo 14", len(product_ids_to_fetch))
                products_data_list = client.read('product.product', product_ids_to_fetch, [
                    'name', 'default_code', 'barcode', 'list_price', 'standard_price',
                    'categ_id', 'uom_id', 'type', 'sale_ok', 'purchase_ok',
                    'description', 'description_sale', 'description_purchase'
                ])
                # Create map: product_id -> product_data
                for product_data in products_data_list:
                    products_data_map[product_data.get('id')] = product_data
                _logger.info("Successfully fetched %s products", len(products_data_map))
            except Exception as e:
                _logger.error("Error batch fetching products: %s", str(e))
                # Continue without products - will skip lines that need products
        
        # Now process each line with batched product data
        for line_data in order_lines_data:
            try:
                # Skip section/note lines
                if line_data.get('display_type') in ('line_section', 'line_note'):
                    continue
                
                # Get or create product
                product = False
                product_id = line_data.get('product_id')
                if product_id:
                    product_id_val = product_id[0] if isinstance(product_id, list) else product_id
                    if product_id_val:
                        product = self.env['product.product'].browse(product_id_val)
                        if not product.exists():
                            # Use batched product data
                            product_data = products_data_map.get(product_id_val)
                            if product_data:
                                # Search for existing product by default_code or name
                                existing_product = self.env['product.product'].search([
                                    '|',
                                    ('default_code', '=', product_data.get('default_code', '')),
                                    ('name', '=', product_data.get('name', ''))
                                ], limit=1)
                                
                                if existing_product:
                                    product = existing_product
                                else:
                                    # Create product template first, then product
                                    # Map product type from Odoo 14 to Odoo 19
                                    product_type = product_data.get('type', 'consu')
                                    # In Odoo 19, valid types are: 'consu', 'service', 'product' (storable)
                                    # Ensure we use valid type - check what's actually available in Odoo 19
                                    try:
                                        # Get the selection field values for type
                                        product_template_model = self.env['product.template']
                                        type_field = product_template_model._fields.get('type')
                                        if type_field and hasattr(type_field, 'selection'):
                                            valid_types = [v[0] for v in type_field.selection]
                                            if product_type not in valid_types:
                                                # Default to first valid type if current type is invalid
                                                product_type = valid_types[0] if valid_types else 'consu'
                                                _logger.warning("Product type '%s' not valid in Odoo 19, using '%s' instead" % (
                                                    product_data.get('type', 'unknown'), product_type
                                                ))
                                    except Exception as e:
                                        # If we can't check, default to 'consu'
                                        if product_type not in ('consu', 'service', 'product'):
                                            product_type = 'consu'
                                        _logger.warning("Could not validate product type, using '%s': %s" % (product_type, str(e)))
                                    
                                    # Get UoM if provided
                                    uom_id = False
                                    if product_data.get('uom_id'):
                                        uom_id_val = product_data.get('uom_id')
                                        uom_id_val = uom_id_val[0] if isinstance(uom_id_val, list) else uom_id_val
                                        if uom_id_val:
                                            uom = self.env['uom.uom'].browse(uom_id_val)
                                            if uom.exists():
                                                uom_id = uom_id_val
                                    
                                    # Create product template
                                    template_vals = {
                                        'name': product_data.get('name', 'Product'),
                                        'default_code': product_data.get('default_code', ''),
                                        'list_price': product_data.get('list_price', 0.0),
                                        'type': product_type,
                                        'sale_ok': product_data.get('sale_ok', True),
                                        'purchase_ok': product_data.get('purchase_ok', False),
                                    }
                                    if uom_id:
                                        template_vals['uom_id'] = uom_id
                                    
                                    try:
                                        product_template = self.env['product.template'].create(template_vals)
                                        # Get the product variant
                                        product = product_template.product_variant_id
                                    except Exception as e:
                                        _logger.error("Error creating product template for %s: %s" % (
                                            product_data.get('name', 'Unknown'), str(e)
                                        ))
                                        # Try with default type if creation failed
                                        if template_vals.get('type') != 'consu':
                                            template_vals['type'] = 'consu'
                                            try:
                                                product_template = self.env['product.template'].create(template_vals)
                                                product = product_template.product_variant_id
                                            except Exception as e2:
                                                _logger.error("Error creating product template with default type: %s" % str(e2))
                                                product = False
                                        else:
                                            product = False
                
                # Get UoM - in Odoo 19, the field is product_uom_id (not product_uom)
                uom = False
                product_uom = line_data.get('product_uom')
                if product_uom:
                    uom_id_val = product_uom[0] if isinstance(product_uom, list) else product_uom
                    if uom_id_val:
                        uom = self.env['uom.uom'].browse(uom_id_val)
                        if not uom.exists():
                            uom = False
                
                # If no UoM from line data, use product's default UoM
                if not uom and product:
                    uom = product.uom_id
                
                # Get taxes
                # In Odoo 19, check if tax_id field exists (it should be tax_id for Many2many)
                taxes = self.env['account.tax']
                tax_ids = line_data.get('tax_id', [])
                if tax_ids:
                    tax_id_list = []
                    for tax_id in tax_ids:
                        if isinstance(tax_id, int):
                            tax_id_list.append(tax_id)
                        elif isinstance(tax_id, (list, tuple)) and len(tax_id) > 0:
                            tax_id_list.append(tax_id[0])
                    
                    if tax_id_list:
                        taxes = self.env['account.tax'].browse(tax_id_list)
                        taxes = taxes.filtered(lambda t: t.exists())
                
                # Create order line
                # In Odoo 19, the field is product_uom_id (not product_uom)
                line_vals = {
                    'order_id': quotation.id,
                    'product_id': product.id if product else False,
                    'name': line_data.get('name', '') or (product.name if product else ''),
                    'product_uom_qty': line_data.get('product_uom_qty', 1.0),
                    'product_uom_id': uom.id if uom else False,  # Fixed: use product_uom_id in Odoo 19
                    'price_unit': line_data.get('price_unit', 0.0),
                    'discount': line_data.get('discount', 0.0),
                    'sequence': line_data.get('sequence', 10),
                }
                
                # Check if tax_id field exists in sale.order.line before setting it
                # In Odoo 19, the field should be tax_id, but let's verify it exists
                sale_order_line_fields = self.env['sale.order.line']._fields
                tax_field_name = None
                if 'tax_id' in sale_order_line_fields:
                    tax_field_name = 'tax_id'
                elif 'tax_ids' in sale_order_line_fields:
                    tax_field_name = 'tax_ids'
                
                if taxes and tax_field_name:
                    line_vals[tax_field_name] = [(6, 0, taxes.ids)]
                elif taxes:
                    _logger.warning("Tax field not found in sale.order.line (checked tax_id, tax_ids), skipping tax assignment. Available tax fields: %s" % 
                                  [f for f in sale_order_line_fields.keys() if 'tax' in f.lower()])
                
                try:
                    self.env['sale.order.line'].create(line_vals)
                except Exception as e:
                    # If creation fails due to tax field, try without taxes
                    if 'tax' in str(e).lower() and tax_field_name and tax_field_name in line_vals:
                        _logger.warning("Error creating order line with taxes, retrying without taxes: %s" % str(e))
                        del line_vals[tax_field_name]
                        self.env['sale.order.line'].create(line_vals)
                    else:
                        raise
                
            except Exception as e:
                _logger.error("Error creating order line: %s" % str(e))
                continue
    
    def action_migrate_sales_orders(self):
        """Migrate sales orders"""
        if self.sales_orders_count == 0:
            raise UserError('No sales orders found. Please check data first.')
        # TODO: Implement migration
        return {'type': 'ir.actions.act_window_close'}
    
    def action_migrate_invoices(self):
        """Migrate invoices"""
        if self.invoices_count == 0:
            raise UserError('No invoices found. Please check data first.')
        # TODO: Implement migration
        return {'type': 'ir.actions.act_window_close'}
    
    def _initialize_items(self):
        """Initialize default customer migration items - not needed for fixed layout"""
        pass
    
    @api.model
    def default_get(self, fields_list):
        """Initialize default customer migration items"""
        res = super().default_get(fields_list)
        return res

